# IQE Requirements report

## Component: platform_ui

### Summary

Overall: 0.0%

Core: 0.0%

Criticals: 0.0%

Highs: No data

Mediums: No data

Lows: No data

### Detailed

Login/logout of c.rh.c (critical): 0.0%

- test_logout[via-chrome] (critical): failed
- test_logout[via-dropdown] (critical): failed
- test_login (critical): error

